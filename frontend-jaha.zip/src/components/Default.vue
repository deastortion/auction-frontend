<!-- Don't mind this vue file, it just serves as a default file with basic template, script and styles -->
<template>
    <div>

    </div>
</template>

<script>
export default {

}
</script>

<style>

</style>